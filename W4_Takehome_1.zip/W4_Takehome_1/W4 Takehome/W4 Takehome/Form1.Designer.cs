﻿namespace w04_appdev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_soccerteamlist = new System.Windows.Forms.Label();
            this.lb_chooseteam = new System.Windows.Forms.Label();
            this.lb_choosenation = new System.Windows.Forms.Label();
            this.cb_choosenation = new System.Windows.Forms.ComboBox();
            this.cb_chooseteam = new System.Windows.Forms.ComboBox();
            this.cb_playerposition = new System.Windows.Forms.ComboBox();
            this.lb_teamname = new System.Windows.Forms.Label();
            this.lb_teamcountry = new System.Windows.Forms.Label();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.lb_playername = new System.Windows.Forms.Label();
            this.lb_playernumber = new System.Windows.Forms.Label();
            this.lb_playerposition = new System.Windows.Forms.Label();
            this.listbox_display = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_addplayer = new System.Windows.Forms.Button();
            this.tb_teamname = new System.Windows.Forms.TextBox();
            this.tb_teamcountry = new System.Windows.Forms.TextBox();
            this.tb_teamcity = new System.Windows.Forms.TextBox();
            this.tb_playername = new System.Windows.Forms.TextBox();
            this.tb_playernumber = new System.Windows.Forms.TextBox();
            this.lb_addingteam = new System.Windows.Forms.Label();
            this.lb_addingplayer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_soccerteamlist
            // 
            this.lb_soccerteamlist.AutoSize = true;
            this.lb_soccerteamlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_soccerteamlist.Location = new System.Drawing.Point(159, 73);
            this.lb_soccerteamlist.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_soccerteamlist.Name = "lb_soccerteamlist";
            this.lb_soccerteamlist.Size = new System.Drawing.Size(201, 29);
            this.lb_soccerteamlist.TabIndex = 0;
            this.lb_soccerteamlist.Text = "Soccer Team List";
            // 
            // lb_chooseteam
            // 
            this.lb_chooseteam.AutoSize = true;
            this.lb_chooseteam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_chooseteam.Location = new System.Drawing.Point(42, 208);
            this.lb_chooseteam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_chooseteam.Name = "lb_chooseteam";
            this.lb_chooseteam.Size = new System.Drawing.Size(166, 29);
            this.lb_chooseteam.TabIndex = 1;
            this.lb_chooseteam.Text = "Choose Team";
            // 
            // lb_choosenation
            // 
            this.lb_choosenation.AutoSize = true;
            this.lb_choosenation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_choosenation.Location = new System.Drawing.Point(42, 138);
            this.lb_choosenation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_choosenation.Name = "lb_choosenation";
            this.lb_choosenation.Size = new System.Drawing.Size(173, 29);
            this.lb_choosenation.TabIndex = 2;
            this.lb_choosenation.Text = "Choose Nation";
            // 
            // cb_choosenation
            // 
            this.cb_choosenation.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_choosenation.FormattingEnabled = true;
            this.cb_choosenation.Location = new System.Drawing.Point(233, 132);
            this.cb_choosenation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cb_choosenation.Name = "cb_choosenation";
            this.cb_choosenation.Size = new System.Drawing.Size(237, 43);
            this.cb_choosenation.TabIndex = 3;
            this.cb_choosenation.SelectedIndexChanged += new System.EventHandler(this.cb_choosenation_SelectedIndexChanged);
            // 
            // cb_chooseteam
            // 
            this.cb_chooseteam.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_chooseteam.FormattingEnabled = true;
            this.cb_chooseteam.Location = new System.Drawing.Point(233, 203);
            this.cb_chooseteam.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cb_chooseteam.Name = "cb_chooseteam";
            this.cb_chooseteam.Size = new System.Drawing.Size(237, 43);
            this.cb_chooseteam.TabIndex = 4;
            this.cb_chooseteam.SelectedIndexChanged += new System.EventHandler(this.cb_chooseteam_SelectedIndexChanged);
            // 
            // cb_playerposition
            // 
            this.cb_playerposition.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_playerposition.FormattingEnabled = true;
            this.cb_playerposition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_playerposition.Location = new System.Drawing.Point(1120, 247);
            this.cb_playerposition.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cb_playerposition.Name = "cb_playerposition";
            this.cb_playerposition.Size = new System.Drawing.Size(96, 43);
            this.cb_playerposition.TabIndex = 5;
            // 
            // lb_teamname
            // 
            this.lb_teamname.AutoSize = true;
            this.lb_teamname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamname.Location = new System.Drawing.Point(502, 131);
            this.lb_teamname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_teamname.Name = "lb_teamname";
            this.lb_teamname.Size = new System.Drawing.Size(147, 29);
            this.lb_teamname.TabIndex = 6;
            this.lb_teamname.Text = "Team Name";
            // 
            // lb_teamcountry
            // 
            this.lb_teamcountry.AutoSize = true;
            this.lb_teamcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcountry.Location = new System.Drawing.Point(502, 190);
            this.lb_teamcountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_teamcountry.Name = "lb_teamcountry";
            this.lb_teamcountry.Size = new System.Drawing.Size(164, 29);
            this.lb_teamcountry.TabIndex = 7;
            this.lb_teamcountry.Text = "Team Country";
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcity.Location = new System.Drawing.Point(502, 257);
            this.lb_teamcity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(122, 29);
            this.lb_teamcity.TabIndex = 8;
            this.lb_teamcity.Text = "Team City";
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playername.Location = new System.Drawing.Point(906, 130);
            this.lb_playername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(152, 29);
            this.lb_playername.TabIndex = 9;
            this.lb_playername.Text = "Player Name";
            // 
            // lb_playernumber
            // 
            this.lb_playernumber.AutoSize = true;
            this.lb_playernumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playernumber.Location = new System.Drawing.Point(906, 190);
            this.lb_playernumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_playernumber.Name = "lb_playernumber";
            this.lb_playernumber.Size = new System.Drawing.Size(174, 29);
            this.lb_playernumber.TabIndex = 10;
            this.lb_playernumber.Text = "Player Number";
            // 
            // lb_playerposition
            // 
            this.lb_playerposition.AutoSize = true;
            this.lb_playerposition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playerposition.Location = new System.Drawing.Point(906, 252);
            this.lb_playerposition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_playerposition.Name = "lb_playerposition";
            this.lb_playerposition.Size = new System.Drawing.Size(174, 29);
            this.lb_playerposition.TabIndex = 11;
            this.lb_playerposition.Text = "Player Position";
            // 
            // listbox_display
            // 
            this.listbox_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbox_display.FormattingEnabled = true;
            this.listbox_display.ItemHeight = 25;
            this.listbox_display.Location = new System.Drawing.Point(49, 278);
            this.listbox_display.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listbox_display.Name = "listbox_display";
            this.listbox_display.Size = new System.Drawing.Size(422, 279);
            this.listbox_display.TabIndex = 12;
            // 
            // btn_remove
            // 
            this.btn_remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove.Location = new System.Drawing.Point(49, 602);
            this.btn_remove.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(118, 57);
            this.btn_remove.TabIndex = 13;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_addteam
            // 
            this.btn_addteam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addteam.Location = new System.Drawing.Point(507, 324);
            this.btn_addteam.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(81, 53);
            this.btn_addteam.TabIndex = 14;
            this.btn_addteam.Text = "Add";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_addplayer
            // 
            this.btn_addplayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addplayer.Location = new System.Drawing.Point(911, 324);
            this.btn_addplayer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_addplayer.Name = "btn_addplayer";
            this.btn_addplayer.Size = new System.Drawing.Size(84, 53);
            this.btn_addplayer.TabIndex = 15;
            this.btn_addplayer.Text = "Add";
            this.btn_addplayer.UseVisualStyleBackColor = true;
            this.btn_addplayer.Click += new System.EventHandler(this.btn_addplayer_Click);
            // 
            // tb_teamname
            // 
            this.tb_teamname.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_teamname.Location = new System.Drawing.Point(693, 125);
            this.tb_teamname.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_teamname.Name = "tb_teamname";
            this.tb_teamname.Size = new System.Drawing.Size(187, 42);
            this.tb_teamname.TabIndex = 16;
            // 
            // tb_teamcountry
            // 
            this.tb_teamcountry.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_teamcountry.Location = new System.Drawing.Point(693, 185);
            this.tb_teamcountry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_teamcountry.Name = "tb_teamcountry";
            this.tb_teamcountry.Size = new System.Drawing.Size(187, 42);
            this.tb_teamcountry.TabIndex = 17;
            // 
            // tb_teamcity
            // 
            this.tb_teamcity.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_teamcity.Location = new System.Drawing.Point(693, 250);
            this.tb_teamcity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_teamcity.Name = "tb_teamcity";
            this.tb_teamcity.Size = new System.Drawing.Size(187, 42);
            this.tb_teamcity.TabIndex = 18;
            // 
            // tb_playername
            // 
            this.tb_playername.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_playername.Location = new System.Drawing.Point(1120, 125);
            this.tb_playername.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_playername.Name = "tb_playername";
            this.tb_playername.Size = new System.Drawing.Size(193, 42);
            this.tb_playername.TabIndex = 19;
            // 
            // tb_playernumber
            // 
            this.tb_playernumber.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_playernumber.Location = new System.Drawing.Point(1120, 185);
            this.tb_playernumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_playernumber.Name = "tb_playernumber";
            this.tb_playernumber.Size = new System.Drawing.Size(193, 42);
            this.tb_playernumber.TabIndex = 20;
            // 
            // lb_addingteam
            // 
            this.lb_addingteam.AutoSize = true;
            this.lb_addingteam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_addingteam.Location = new System.Drawing.Point(598, 73);
            this.lb_addingteam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_addingteam.Name = "lb_addingteam";
            this.lb_addingteam.Size = new System.Drawing.Size(158, 29);
            this.lb_addingteam.TabIndex = 21;
            this.lb_addingteam.Text = "Adding Team";
            // 
            // lb_addingplayer
            // 
            this.lb_addingplayer.AutoSize = true;
            this.lb_addingplayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_addingplayer.Location = new System.Drawing.Point(1032, 73);
            this.lb_addingplayer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_addingplayer.Name = "lb_addingplayer";
            this.lb_addingplayer.Size = new System.Drawing.Size(163, 29);
            this.lb_addingplayer.TabIndex = 22;
            this.lb_addingplayer.Text = "Adding Player";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 707);
            this.Controls.Add(this.lb_addingplayer);
            this.Controls.Add(this.lb_addingteam);
            this.Controls.Add(this.tb_playernumber);
            this.Controls.Add(this.tb_playername);
            this.Controls.Add(this.tb_teamcity);
            this.Controls.Add(this.tb_teamcountry);
            this.Controls.Add(this.tb_teamname);
            this.Controls.Add(this.btn_addplayer);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.listbox_display);
            this.Controls.Add(this.lb_playerposition);
            this.Controls.Add(this.lb_playernumber);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.lb_teamcountry);
            this.Controls.Add(this.lb_teamname);
            this.Controls.Add(this.cb_playerposition);
            this.Controls.Add(this.cb_chooseteam);
            this.Controls.Add(this.cb_choosenation);
            this.Controls.Add(this.lb_choosenation);
            this.Controls.Add(this.lb_chooseteam);
            this.Controls.Add(this.lb_soccerteamlist);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_soccerteamlist;
        private System.Windows.Forms.Label lb_chooseteam;
        private System.Windows.Forms.Label lb_choosenation;
        private System.Windows.Forms.ComboBox cb_choosenation;
        private System.Windows.Forms.ComboBox cb_chooseteam;
        private System.Windows.Forms.ComboBox cb_playerposition;
        private System.Windows.Forms.Label lb_teamname;
        private System.Windows.Forms.Label lb_teamcountry;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.Label lb_playernumber;
        private System.Windows.Forms.Label lb_playerposition;
        private System.Windows.Forms.ListBox listbox_display;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_addplayer;
        private System.Windows.Forms.TextBox tb_teamname;
        private System.Windows.Forms.TextBox tb_teamcountry;
        private System.Windows.Forms.TextBox tb_teamcity;
        private System.Windows.Forms.TextBox tb_playername;
        private System.Windows.Forms.TextBox tb_playernumber;
        private System.Windows.Forms.Label lb_addingteam;
        private System.Windows.Forms.Label lb_addingplayer;
    }
}

