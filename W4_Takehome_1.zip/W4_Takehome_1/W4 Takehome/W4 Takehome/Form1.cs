﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace w04_appdev
{
    public partial class Form1 : Form
    {
        List<Team> Teamlist = new List<Team>();

        public Form1()
        {
            InitializeComponent();

            string[] array_team1 = { "England", "England", "France" };
            string[] array_team2 = { "Manchester", "Brooklyn", "Paris" };
            string[] array_team3 = { "Manchester United", "Brooklyn", "Xīwǒdeqiú" };
            string[] array_team1p = { "Marcus Rashford", "leo Paul", "Bruno Fernandes", "Paul Pogba", "Harry Maguire", "David de Gea", "Luke Shaw", "Aaron Wan-Bissaka", "Mason Greenwood", "Fred", "Edinson Cavani", "Raphael Varane" };
            string[] array_team2p = { "Jamie Vardy", "Andrew Benze", "Andrew Robertson", "Harry Maguire", "James Ward-Prowse", "Aaron Wan-Bissaka", "Jesse Lingard", "Harvey Barnes", "John Stones", "Ben White", "Emile Smith Rowe", "Connor Gallagher" };
            string[] array_team3p = { "Kylian Mbappé", "Kanté Le Griezmann", "Antoine jemann", "Paul Pogba", "N'Golo Kanté", "Karim Benzema", "Raphael Varane", "Olivier Giroud", "Benjamin Pavard", "Kingsley Coman", "Hugo Lloris", "Presnel Kimpembe" };
            string[] array_teamnumber = { "1", "2", "3", "6", "9", "10", "13", "15", "18", "19", "21", "22" };
            string[] array_teamposition = { "GK", "DF", "DF", "DF", "MF", "MF", "MF", "MF", "MF", "FW", "FW", "FW" };

            for (int i = 0; i < 3; i++)
            {
                Team team = new Team();
                team.teamCountry = array_team1[i];
                team.teamCity = array_team2[i];
                team.teamName = array_team3[i];
                List<Player> playerlist = new List<Player>();
                for (int j = 0; j < 12; j++)
                {
                    Player player = new Player();
                    if (i == 0)
                    {
                        player.playerName = array_team1p[j];
                    }
                    else if (i == 1)
                    {
                        player.playerName = array_team2p[j];
                    }
                    else
                    {
                        player.playerName = array_team3p[j];
                    }
                    player.playerNum = array_teamnumber[j];
                    player.playerPos = array_teamposition[j];
                    playerlist.Add(player);
                }
                team.Players = playerlist;
                Teamlist.Add(team);
            }

            for (int k = 0; k < Teamlist.Count; k++)
            {
                if (!cb_choosenation.Items.Contains(Teamlist[k].teamCountry))
                {
                    cb_choosenation.Items.Add(Teamlist[k].teamCountry);
                }
            }
        }

        private void cb_choosenation_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_chooseteam.Items.Clear();
            cb_chooseteam.Text = "";
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string country = cb_choosenation.SelectedItem.ToString();
                if (Teamlist[i].teamCountry == country)
                {
                    cb_chooseteam.Items.Add(Teamlist[i].teamName);
                }
            }
        }

        private void cb_chooseteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox_display.Items.Clear();
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = cb_chooseteam.SelectedItem.ToString();
                if (Teamlist[i].teamName == team)
                {
                    for(int j = 0; j< Teamlist[i].Players.Count; j++)
                    {
                        string nama = Teamlist[i].Players[j].playerName;
                        string nom = Teamlist[i].Players[j].playerNum;
                        string pos = Teamlist[i].Players[j].playerPos;
                        listbox_display.Items.Add("("+ nom + ") "+ nama + ","+ pos);
                    }
                    break;
                }
            }
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            bool allow = true;
            if (tb_teamname.Text != "" && tb_teamcountry.Text != "" && tb_teamcity.Text != "")
            {
                for(int i = 0; i < Teamlist.Count; i++)
                {
                    if (Teamlist[i].teamName == tb_teamcountry.Text)
                    {
                        MessageBox.Show("Team already has been added");
                        break;
                        allow = true;
                    }
                }
                if (allow)
                {
                    Team team = new Team();
                    team.teamCountry = tb_teamname.Text;
                    team.teamName = tb_teamcountry.Text;
                    team.teamCity = tb_teamcity.Text;
                    List<Player> playerlist = new List<Player>();
                    team.Players = playerlist;
                    Teamlist.Add(team);

                    tb_teamname.Text = "";
                    tb_teamcountry.Text = "";
                    tb_teamcity.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Please fill in the textbox");
            }

            for (int o = 0; o < Teamlist.Count; o++)
            {
                if (cb_choosenation.Items.Contains(Teamlist[o].teamCountry))
                {

                }
                else
                {
                    cb_choosenation.Items.Add(Teamlist[o].teamCountry);
                }
            }

        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = cb_chooseteam.SelectedItem.ToString();
                if (Teamlist[i].teamName == team && Teamlist[i].Players.Count > 11)
                {
                    Teamlist[i].Players.Remove(Teamlist[i].Players[listbox_display.SelectedIndex]);
                    break;
                }
                else if (Teamlist[i].Players.Count <= 11)
                {
                    MessageBox.Show("Not enough players");
                    break;
                }
                
            }

            listbox_display.Items.Clear();
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = cb_chooseteam.SelectedItem.ToString();
                if (Teamlist[i].teamName == team)
                {
                    for (int j = 0; j < Teamlist[i].Players.Count; j++)
                    {
                        string name = Teamlist[i].Players[j].playerName;
                        string number = Teamlist[i].Players[j].playerNum;
                        string position = Teamlist[i].Players[j].playerPos;
                        listbox_display.Items.Add("[" + number + "] " + name + "," + position);
                    }
                    break;
                }
            }
        }

        private void btn_addplayer_Click(object sender, EventArgs e)
        {
            string[] Position = { "GK", "DF", "MF", "FW" };
            string name = tb_playername.Text;
            string number = tb_playernumber.Text;
            string position = Position[cb_playerposition.SelectedIndex];

            if (name != "" && number != "" && cb_playerposition.SelectedIndex != -1)
            {
                if (cb_choosenation.SelectedIndex != -1 && cb_chooseteam.SelectedIndex != -1)
                {
                    for (int i = 0; i < Teamlist.Count; i++)
                    {
                        string team = cb_chooseteam.SelectedItem.ToString();
                        if (Teamlist[i].teamName == team)
                        {
                            bool check = true;
                            for(int k = 0; k < Teamlist[i].Players.Count; k++)
                            {
                                if (Teamlist[i].Players[k].playerName == name)
                                {
                                    check = false;
                                } 
                            }
                            if (check)
                            {
                                Player player = new Player();
                                player.playerName = name;
                                player.playerNum = number;
                                player.playerPos = position;
                                Teamlist[i].Players.Add(player);
                                listbox_display.Items.Add("[" + number + "] " + name + "," + position);
                            }
                            else
                            {
                                MessageBox.Show("Player already exist");
                            }
                            break;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a team");
                }
                tb_playername.Text = "";
                tb_playernumber.Text = "";
                cb_playerposition.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Please fill the textbox");
            }
        }
    }
}
